import requests,pathlib
p=pathlib.Path(r'D:\Open-Space\campaigns\euclid-line-alias-2715244-20261118');u='https://irsa.ipac.caltech.edu/TAP/sync';oid='2715244005677000411'
queries={'association':f'SELECT * FROM euclid.objectid_spectrafile_association_dr1 WHERE objectid={oid}','ranks':f'SELECT * FROM euclid_dr1_spectro_z_spe_galaxy_candidates_deep WHERE object_id={oid}','lines':f'SELECT * FROM euclid_dr1_spectro_line_features_spe_line_features_deep WHERE object_id={oid}','mer':f'SELECT object_id,ra,dec FROM euclid_dr1_mer_catalogue_deep_survey WHERE object_id={oid}'}
for name,q in queries.items():
 r=requests.get(u,params={'REQUEST':'doQuery','LANG':'ADQL','FORMAT':'csv','QUERY':q},timeout=60);r.raise_for_status();(p/(name+'.csv')).write_bytes(r.content);(p/(name+'.url.txt')).write_text(r.url);print(name,r.status_code,len(r.content),r.text[:1800])
