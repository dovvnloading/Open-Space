import csv,requests,pathlib,hashlib
p=pathlib.Path(r'D:\Open-Space\campaigns\euclid-line-alias-2715244-20261118'); rows=list(csv.DictReader((p/'association.csv').open()))
for i,x in enumerate(rows):
 url='https://irsacloud.ipac.caltech.edu/api/spectrumdm/convert/'+x['path']; params={'dataset_id':'euclid_combspec_dr1','hdu':x['hdu']};r=requests.get(url,params=params,timeout=90);r.raise_for_status();(p/f'spectrum-{i+1}.vot').write_bytes(r.content);(p/f'spectrum-{i+1}.url.txt').write_text(r.url);print(i,r.status_code,len(r.content),hashlib.sha256(r.content).hexdigest(),r.text[:400])
