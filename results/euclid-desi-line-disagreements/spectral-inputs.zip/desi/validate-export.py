import json,csv,pathlib,hashlib,math
p=pathlib.Path(__file__).parent;source=pathlib.Path(r'D:\Open-Space\campaigns\euclid-desi-dr1-development-20261118-scout\zpix-development.csv')
with source.open(newline='',encoding='utf8') as f: catalog={r['targetid']:r for r in csv.DictReader(f)}
lines={'OII_3726':3726.03,'OII_3729':3728.82,'Hdelta':4101.74,'Hgamma':4340.47,'Hbeta':4861.33,'OIII_4959':4958.91,'OIII_5007':5006.84,'OI_6300':6300.30,'NII_6548':6548.05,'Halpha':6562.80,'NII_6583':6583.45,'SII_6716':6716.44,'SII_6731':6730.82}
receipts=[]
for i in range(1,4):
 path=p/f'response-{i}.json';data=json.loads(path.read_bytes()); assert len(data)==2
 meta,r=data;t=str(r['targetid']); cat=catalog[t]
 assert 270.5<=float(cat['mean_fiber_ra'])<273 and 67<=float(cat['mean_fiber_dec'])<=68.5
 assert r['survey']==cat['survey'] and r['program']==cat['program'] and str(r['healpix'])==cat['healpix'] and abs(r['redshift']-float(cat['z']))<1e-12 and r['redshift_warning']==int(cat['zwarn']) and r['specprimary']
 arr=[r[k] for k in ('wavelength','flux','ivar','mask','model')];assert len(set(map(len,arr)))==1
 wave=arr[0];assert all(wave[j+1]>wave[j] for j in range(len(wave)-1))
 out=p/f'{t}-spectrum.csv'
 with out.open('w',newline='',encoding='utf8') as f:
  w=csv.writer(f);w.writerow(['wavelength_A','flux','ivar','mask','model']);w.writerows(zip(*arr))
 coverage={k:{'observed_A':v*(1+r['redshift']),'covered':wave[0]<=v*(1+r['redshift'])<=wave[-1]} for k,v in lines.items()}
 rec={'targetid':t,'survey':r['survey'],'program':r['program'],'healpix':r['healpix'],'z':r['redshift'],'zerr':r['redshift_err'],'zwarn':r['redshift_warning'],'deltachi2':float(cat['deltachi2']),'n':len(wave),'wavelength_range_A':[wave[0],wave[-1]],'finite_flux':sum(x is not None and math.isfinite(x) for x in arr[1]),'finite_model':sum(x is not None and math.isfinite(x) for x in arr[4]),'usable':sum(x is not None and math.isfinite(x) and x>0 and m==0 for x,m in zip(arr[2],arr[3])),'coverage':coverage,'raw_response':path.name,'raw_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'numeric_csv':out.name,'numeric_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'units':meta['UNITS']}
 receipts.append(rec)
(p/'receipt.json').write_text(json.dumps(receipts,indent=2)+'\n',encoding='utf8'); print(json.dumps([{k:v for k,v in r.items() if k not in ['coverage','units']}|{'covered':[k for k,v in r['coverage'].items() if v['covered']],'not_covered':[k for k,v in r['coverage'].items() if not v['covered']]} for r in receipts],indent=2))

