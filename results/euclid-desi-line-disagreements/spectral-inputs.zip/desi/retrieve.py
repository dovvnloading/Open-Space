import sys,pathlib,json,hashlib,requests,urllib.parse
p=pathlib.Path(__file__).parent
sys.path.insert(0,r'D:\Open-Space\campaigns\euclid-desi-dr1-development-20261118-scout\dependencies')
from sparcl.client import SparclClient
orig=requests.sessions.Session.send
n=0
def capture(self,request,**kwargs):
 global n
 if '/api/spectras/' in request.url:
  request.url=request.url.replace('format=pkl','format=json')
 r=orig(self,request,**kwargs)
 if '/api/spectras/' in request.url:
  n+=1;(p/f'response-{n}.json').write_bytes(r.content)
  (p/f'request-{n}.json').write_text(json.dumps({'url':request.url,'method':request.method,'body':request.body.decode() if isinstance(request.body,bytes) else request.body,'status':r.status_code,'content_type':r.headers.get('content-type')},indent=2),encoding='utf8')
 return r
requests.sessions.Session.send=capture
c=SparclClient(announcement=False,read_timeout=80)
for t in [39633470531569939,39633470531569843,39633470531567720]:
 try:
  c.retrieve_by_specid([t],dataset_list=['DESI-DR1'],include=['targetid','specid','data_release','survey','program','healpix','ra','dec','redshift','redshift_err','redshift_warning','spectype','specprimary','file','wavelength','flux','ivar','mask','model'],limit=20)
 except Exception as e: print(t,type(e).__name__,str(e)[:150])
